package com
 class homeloan
 {
   var loan_amt = 100000
   def comp()
   {
     println("return amount = "+loan_amt*1.05)
   }
 }
