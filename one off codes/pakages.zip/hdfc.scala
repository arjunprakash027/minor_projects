package com
 class hdfc
 {
   var client_id = 089
   def comp()
   {
     println("client id="+client_id)
   }
 }
