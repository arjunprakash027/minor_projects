object Main {
  def main(args: Array[String]): Unit = {
    import com._
    val obj = new ibm()
    val obj2 = new hdfc()
    val obj3 = new loan()
    val obj4 = new homeloan()
    obj.comp();
    obj2.comp();
    obj3.comp();
    obj4.comp();
  }
}