package com
 class ibm
 {
   var company_name = "ibm"
   def comp()
   {
     println(company_name)
   }
 }
