package com
 class loan
 {
   var eligiblity = "yes"
   def comp()
   {
     if(eligiblity=="yes"){println("loan will be granted")}
     else{println("no loan")}   
   }
 }
